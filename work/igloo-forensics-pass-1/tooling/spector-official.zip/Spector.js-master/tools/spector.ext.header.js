var spectorBundleHook = function(){
