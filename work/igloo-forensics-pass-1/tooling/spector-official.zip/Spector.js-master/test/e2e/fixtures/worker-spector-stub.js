self.__spectorTestInjected = true;
